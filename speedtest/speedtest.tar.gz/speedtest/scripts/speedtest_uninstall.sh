#!/bin/sh

rm -f /jffs/softcenter/scripts/speedtest_config.sh
rm -f /jffs/softcenter/bin/speedtest
rm -f /jffs/softcenter/res/icon-speedtest.png
rm -f /jffs/softcenter/webs/Module_speedtest.asp
